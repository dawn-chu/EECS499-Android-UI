package com.adherence.adherence;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.view.View;
import android.view.View.OnClickListener;
import android.app.Activity;
import android.app.AlertDialog;
import android.util.Log;
import android.view.Menu;
import android.widget.EditText;
import android.widget.Toast;
import android.content.Intent;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button conformButton = (Button) this.findViewById(R.id.conformButton);
        Button cancelButton= (Button) this.findViewById(R.id.cancelButton);
        OnClickListener ocl = new OnClickListener() {
            @Override
            public void onClick(View arg0) {
                Login(arg0);
            }
        };
        conformButton.setOnClickListener(ocl);
        cancelButton.setOnClickListener(ocl);
    }

    public void Login(View arg0){
        EditText name=(EditText)findViewById(R.id.username);
        EditText pwd=(EditText)findViewById(R.id.pwd);
        Button bt=(Button)findViewById(arg0.getId());
        String text=bt.getText().toString();
        if(text.equals("login")){
            String name1=name.getText().toString();
            String pwd1=pwd.getText().toString();
            if(name1.equals("1") && pwd1.equals("2")){
                Intent intent = new Intent();
                intent.setClass(MainActivity.this, NextActivity.class);
                MainActivity.this.startActivity(intent);
            }
            else{
                Toast toast=Toast.makeText(this,"Wrong account or password, please input again",Toast.LENGTH_LONG);
                toast.show();
            }
        }
        else{
            name.setText("");
            pwd.setText("");
        }

    }
}
